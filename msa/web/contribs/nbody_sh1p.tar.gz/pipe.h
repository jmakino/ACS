/*
 * Header file for the MPI pipeline
 *        see pipe.C for details
 *
 */

#include "mpi.h"
#include <stdio.h>
#include <memory.h>
#include <malloc.h>

typedef struct {
    MPI_Comm     mycomm;
    int          left, right;
    MPI_Datatype type;
    void         *buf1, *buf2, *buf;
    MPI_Request  requests[2];
    int          stage, last_stage, maxlen;
    int          typesize;
} MPE_Pipe;

void MPE_Pipe_create(MPI_Comm comm, MPI_Datatype type, 
		     int maxsize, void **pipe);
void MPE_Pipe_start(void* pipe, void* mybuf, int len, int qcopy);
void MPE_Pipe_push(void* pipe, void** recvbuf, int* recvlen);
void MPE_Pipe_free(void** pipe);

