               // Time-stamp: <2002-01-18 21:51:36 piet>
              // Time-stamp: <2003-21-10 03:22:41 spz>
             //================================================================
            //                                                                |
           //           /__----__                         ........            |
          //       .           \                     ....:        :.          |
         //       :                 _\|/_         ..:                         |
        //       :                   /|\         :                     _\|/_  |
       //  ___   ___                  _____                      ___    /|\   |
      //  /     |   \    /\ \     / |   |   \  / |        /\    |   \         |
     //  |   __ |___/   /  \ \   /  |   |    \/  |       /  \   |___/         |
    //   |    | |  \   /____\ \ /   |   |    /   |      /____\  |   \     \/  |
   //     \___| |   \ /      \ V    |   |   /    |____ /      \ |___/     |   |
  //                                                                      /   |
 //              :                       _/|     :..                    |/    |
//                :..               ____/           :....          ..         |
/*   o   //          :.    _\|/_     /                   :........:           |
 *  O  `//\                 /|\                                               |
 *  |     /\                                                                  |
 *=============================================================================
 *
 *  nbody_sh1p.C: an N-body integrator with a shared but variable time step
 *                (the same for all particles but changing in time), using
 *                the Hermite integration scheme.
 *                        
 *                ref.: Hut, P., Makino, J. & McMillan, S., 1995,
 *                      Astrophysical Journal Letters 443, L93-L96.
 *                
 *                The original version (nbody_sh1.C) has been adapted 
 *                for a parallel ring algorithm using the MPI library. 
 *_____________________________________________________________________________
 *
 *  usage: nbody_sh1p [-h (for help)] [-d step_size_control_parameter]
 *                    [-e diagnostics_interval] [-o output_interval]
 *                    [-t total_duration] [-i (start output at t = 0)]
 *                    [-x (extra debugging diagnostics)]
 * 
 *         "step_size_control_parameter" is a coefficient determining the
 *            the size of the shared but variable time step for all particles
 *
 *         "diagnostics_interval" is the time between output of diagnostics,
 *            in the form of kinetic, potential, and total energy; with the
 *            -x option, a dump of the internal particle data is made as well
 * 
 *         "output_interval" is the time between successive snapshot outputs
 *
 *         "total_duration" is the integration time, until the program stops
 *
 *         Input and output are written from the standard i/o streams.  Since
 *         all options have sensible defaults, the simplest way to run the code
 *         is by only specifying the i/o files for the N-body snapshots:
 *
 *            nbody_sh1 < data.in > data.out
 *
 *         The diagnostics information will then appear on the screen.
 *         To capture the diagnostics information in a file, capture the
 *         standard error stream as follows:
 *
 *            (nbody_sh1 < data.in > data.out) >& data.err
 *
 *  Note: if any of the times specified in the -e, -o, or -t options are not an
 *        an integer multiple of "step", output will occur slightly later than
 *        predicted, after a full time step has been taken.  And even if they
 *        are integer multiples, round-off error may induce one extra step.
 *_____________________________________________________________________________
 *
 *  External data format:
 *
 *     The program expects input of a single snapshot of an N-body system,
 *     in the following format: the number of particles in the snapshot n;
 *     the time t; mass mi, position ri and velocity vi for each particle i,
 *     with position and velocity given through their three Cartesian
 *     coordinates, divided over separate lines as follows:
 *
 *                      n
 *                      t
 *                      m1 r1_x r1_y r1_z v1_x v1_y v1_z
 *                      m2 r2_x r2_y r2_z v2_x v2_y v2_z
 *                      ...
 *                      mn rn_x rn_y rn_z vn_x vn_y vn_z
 *
 *     Output of each snapshot is written according to the same format.
 *
 *  Internal data format:
 *
 *     The data for an N-body system is stored internally as a 1-dimensional
 *     array for particle characteristics collected in a structure.
 *     The structure contains particle identity, mass, and 1-dimensional 
 *     arrays for the position, velocity, acceleration and jerk.
 *     The particle identity is added in the MPI implemetation to prevent 
 *     computing acceleration and force on itself.
 *_____________________________________________________________________________
 *
 *  Extera about the MPI implementation
 *
 *     The topology assumes a 1-dimensional ring of processors with 
 *     int(N/p) particles per processor. At the moment only p*int(N/p)
 *     particles can be integrated; excess of p*int(N/p) particles are ignored 
 *     in the input and particle residtribution.
 *     All I/O is via the root processor (0). 
 *
 *     Possible adjustments and improvement:
 *     - It is assumed that each star has a unique identifier, which is 
 *       provided at runtime.
 *     - For the comminucation all particle information is passed to other 
 *       processes, where this is not always required.
 *     - Since each processor works with N/p particles, little memory per 
 *       node is requires, the root node, however, requires to store an 
 *       entire snapshot at I/O.
 *     - Acceleration and jerk are computed for all particles individually, 
 *       the symmetry in the force calculation is not used.
 *_____________________________________________________________________________
 *
 *  Compiling
 *
 *    Successfull compilation requires the presence of MPI or some compatible 
 *    derivative such as MPICH.
 *    Here we give the command line example for compilation with MPICH 
 *    assuming that it is installed on your system on /usr/local/MPI
 *
 *    First: create the pipe.o object file:
 *    %> /usr/local/MPI/bin/mpiCC -g -O2 -I/usr/local/MPI/include -c pipe.C
 *
 *    Second: compile nbody_sh1p.C and link it with pipe.o:
 *    %> /usr/local/MPI/bin/mpiCC -g -O2 -I/usr/local/MPI/include \
 *          nbody_sh1p.C -L/usr/local/MPI/lib -lmpich pipe.o -o nbody_sh1p
 *_____________________________________________________________________________
 *
 *  Testrun
 * 
 *    Test run with 6 processors by the following command line
 *    %> /usr/local/MPI/bin/mpirun -np 6 ./nbody_sh1p < n24body.in
 *_____________________________________________________________________________
 *
 *    version 1:  Jan 2002   Piet Hut, Jun Makino
 *    version 2:  Okt 2003   Simon Portegies Zwart
 *_____________________________________________________________________________
 */

#include  <iostream>
#include  <cmath>                          // to include sqrt(), etc.
#include  <cstdlib>                        // for atoi() and atof()
#include  <unistd.h>                       // for getopt()
#include  <mpi.h>                          // include the MPI library
#include  "pipe.h"                         // the MPI pipe routines

using namespace std;
typedef double  real;                      // "real" as a general name for the
                                           // standard floating-point data type

// practical for debugging
#define PRI(x) {for (int __pri__ = 0; __pri__ < x; __pri__++) cerr << " ";}
#define PR(x)  cerr << #x << " = " << x << " "
#define PRC(x) cerr << #x << " = " << x << ",  "
#define PRL(x) cerr << #x << " = " << x << endl

const int NDIM = 3;                        // number of spatial dimensions
const real VERY_LARGE_NUMBER = 1e300;
const int root = 0;                        // identity of the root processor

// The Particle structure
typedef struct {
  int id;
  real mass;
  real pos[NDIM];
  real vel[NDIM];
  real acc[NDIM];
  real jerk[NDIM];
} Particle;

void correct_step(Particle p[], Particle po[], int n, real dt);
void evolve(Particle p[],
            int n, real & t, real dt_param, real dt_dia, real dt_out,
            real dt_tot, bool init_out, bool x_flag, void *pipe,
	    MPI_Datatype particletype);
void evolve_step(Particle p[], int n, real & t,
                 real dt, real & epot, real & coll_time,
		 void *pipe);
void get_acc_jerk_pot_coll(Particle pl[], int nl, 
			   Particle po[], int no, 
			   real & epot, real & coll_time);
Particle * get_snapshot(int &n, real &t, MPI_Datatype &particletype);
void predict_step(Particle p[], int n, real dt);
void put_snapshot(Particle p[], int n, real t, MPI_Datatype particletype);
bool read_options(int argc, char *argv[], real & dt_param, real & dt_dia,
                  real & dt_out, real & dt_tot, bool & i_flag, bool & x_flag);
void write_diagnostics(Particle p[], int n, real t, real epot,
                       int nsteps, real & einit, bool init_flag,
                       bool x_flag, real &tcpu);


#define loop(idx,last) for (idx = 0; idx < last ; idx++)

void uniform(real a, real *x);
void uniform(Particle p[], int n);
void get_acc_jerk_pot_coll(Particle p[], int n, real &epot, real &coll_time, 
			   void *pipe);

/*-----------------------------------------------------------------------------
 *  main  --  reads option values, reads a snapshot, and launches the
 *            integrator
 *-----------------------------------------------------------------------------
 */

int main(int argc, char *argv[])
{

    // initialize MPI
    int rank, size;
    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &size );

    real  dt_param = 0.03;     // control parameter to determine time step size
    real  dt_dia = 1;          // time interval between diagnostics output
    real  dt_out = 1;          // time interval between output of snapshots
    real  dt_tot = 10;         // duration of the integration
    bool  init_out = false;    // if true: snapshot output with start at t = 0
                               //          with an echo of the input snapshot
    bool  x_flag = false;      // if true: extra debugging diagnostics output

    if (! read_options(argc, argv, dt_param, dt_dia, dt_out, dt_tot, init_out,
                       x_flag))
        return 1;                // halt criterion detected by read_options()

    int n;
    real t;
    MPI_Datatype particletype;
    Particle *p = get_snapshot(n, t, particletype);

    real noutp = 1;
    real dt;
    put_snapshot(p, n, t, particletype);

    void * pipe;  // Create a MPI pipe for a 1-dimensional ring topology
    MPE_Pipe_create( MPI_COMM_WORLD, particletype, n, &pipe );

    evolve(p, n, t, dt_param, dt_dia, dt_out, dt_tot, init_out,
	   x_flag, pipe, particletype);

    delete []p;

    MPE_Pipe_free( &pipe );             // Clean up MPI
    MPI_Type_free( &particletype );
    MPI_Finalize();

}

/*-----------------------------------------------------------------------------
 *  read_options  --  reads the command line options, and implements them.
 *
 *  note: when the help option -h is invoked, the return value is set to false,
 *        to prevent further execution of the main program; similarly, if an
 *        unknown option is used, the return value is set to false.
 *-----------------------------------------------------------------------------
 */

bool read_options(int argc, char *argv[], real & dt_param, real & dt_dia,
                  real & dt_out, real & dt_tot, bool & i_flag, bool & x_flag)
{
    int c;
    while ((c = getopt(argc, argv, "hd:e:o:t:ix")) != -1)
        switch(c){
            case 'h': cerr << "usage: " << argv[0]
                           << " [-h (for help)]"
                           << " [-d step_size_control_parameter]\n"
                           << "         [-e diagnostics_interval]"
                           << " [-o output_interval]\n"
                           << "         [-t total_duration]"
                           << " [-i (start output at t = 0)]\n"
                           << "         [-x (extra debugging diagnostics)]"
                           << endl;
                      return false;         // execution should stop after help
            case 'd': dt_param = atof(optarg);
                      break;
            case 'e': dt_dia = atof(optarg);
                      break;
            case 'i': i_flag = true;
                      break;
            case 'o': dt_out = atof(optarg);
                      break;
            case 't': dt_tot = atof(optarg);
                      break;
            case 'x': x_flag = true;
                      break;
            case '?': cerr << "usage: " << argv[0]
                           << " [-h (for help)]"
                           << " [-d step_size_control_parameter]\n"
                           << "         [-e diagnostics_interval]"
                           << " [-o output_interval]\n"
                           << "         [-t total_duration]"
                           << " [-i (start output at t = 0)]\n"
                           << "         [-x (extra debugging diagnostics)]"
                           << endl;
                      return false;        // execution should stop after error
            }

    return true;                         // ready to continue program execution
}

/*-----------------------------------------------------------------------------
 *  get_snapshot  --  reads a single snapshot with the root processor 
 *                    from the input stream cin.
 *
 *  note: in this implementation, particle number, time and the data for
 *        individual particles are read in.
 *        All communication goes via the root (0) process.
 *  note: The routine also declared the MPI_Datatype particletype which is
 *        the contianer for the particle data.
 *        This structure is used for further MPI comminication.
 *-----------------------------------------------------------------------------
 */

Particle *get_snapshot(int &n, real &t,
		       MPI_Datatype &particletype)
{

  int rank, size;
  MPI_Comm_rank( MPI_COMM_WORLD, &rank );
  MPI_Comm_size( MPI_COMM_WORLD, &size );

  Particle *p_tmp;
  if(rank==root) {
    cerr << "Reading snapshot" << endl;
    cin >> n;
    cin >> t;

    p_tmp = new Particle[n];

    for(int i=0; i<n; i++) {
      p_tmp[i].id = i;
      cin >> p_tmp[i].mass;                         // mass of particle i
      for (int k = 0; k < NDIM; k++)
	cin >> p_tmp[i].pos[k];                 // position of particle i
      for (int k = 0; k < NDIM; k++)
	cin >> p_tmp[i].vel[k];                 // velocity of particle i
    }
  }

  MPI_Bcast(&n,1,MPI_INT,root,MPI_COMM_WORLD); // broadcasts particle number

  int n_local = (int)(floor(1.0*n/size));
  if(n != n_local*size && rank==root) {
    cerr << "WARNING: Paticle number in input is not a mulitple of the number of processors." 
	 << endl;
    cerr << "         Action: Reduce particle number to n = " 
	 << n_local*size << "." << endl;
  }
  Particle *p = new Particle[n_local];

  // defining the particletype
  int inputblockcounts[2] = {1, 13};
  MPI_Datatype ntypes[] = {MPI::INT, MPI::DOUBLE};
  MPI::Aint displs[2];
  MPI_Address(&p[0].id, &displs[0]);
  MPI_Address(&p[0].mass, &displs[1]);
  displs[1] -= displs[0];        //make them relative
  displs[0] = 0;

  MPI_Type_struct(2, inputblockcounts, displs, ntypes, &particletype);
  MPI_Type_commit(&particletype);

  // Distribute the particles over the processors
  MPI_Scatter(p_tmp,n_local,particletype,p,n_local,particletype,root,MPI_COMM_WORLD);
  n = n_local;
  MPI_Bcast(&t,1,MPI_DOUBLE,root,MPI_COMM_WORLD);

  delete []p_tmp;
  return p;
}

/*-----------------------------------------------------------------------------
 *  put_snapshot  --  writes a single snapshot on the output stream cout.
 *
 *  note: Communication goes via the root (0) proceesor
 *-----------------------------------------------------------------------------
 */

void put_snapshot(Particle p[], int n, real t,
		  MPI_Datatype particletype)
{

    int rank;
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );

    int ntot;
    MPI_Allreduce(&n, &ntot, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD );

    Particle *p_all;
    if(rank==root) {
      p_all = new Particle[ntot];
    }
    MPI_Gather(p,n,particletype,p_all,n,particletype,root,MPI_COMM_WORLD);

    cout.precision(16);                       // full double precision
    if(rank==root) {
      cout << ntot << endl;                     // N, total particle number
      cout << t << endl;                        // current time
    for (int i = 0; i < ntot ; i++){
      cout << p_all[i].mass;                      // mass of particle i
        for (int k = 0; k < NDIM; k++)
            cout << ' ' << p_all[i].pos[k];         // position of particle i
        for (int k = 0; k < NDIM; k++)
            cout << ' ' << p_all[i].vel[k];         // velocity of particle i
        cout << endl;
    }
    delete []p_all;
    }
}

    
/*-----------------------------------------------------------------------------
 *  write_diagnostics  --  writes diagnostics on the error stream cerr:
 *                         current time; number of integration steps so far;
 *                         kinetic, potential, and total energy; absolute and
 *                         relative energy errors since the start of the run.
 *                         If x_flag (x for eXtra data) is true, all internal
 *                         data are dumped for each particle (mass, position,
 *                         velocity, acceleration, and jerk).
 *
 *  note: the kinetic energy is calculated here, while the potential energy is
 *        calculated in the function get_acc_jerk_pot_coll() and broadcasted
 *        by the other processors.
 *
 *  note: Communication goes via the root (0) proceesor
 *-----------------------------------------------------------------------------
 */

void write_diagnostics(Particle p[], int n, real t, real epot_local,
                       int nsteps, real & einit, bool init_flag,
                       bool x_flag, real &tcpu)
{

    int rank;
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );

    real ekin_local = 0;       // kinetic energy of the n-body system
    for (int i = 0; i < n ; i++)
        for (int k = 0; k < NDIM ; k++)
            ekin_local += 0.5 * p[i].mass * p[i].vel[k] * p[i].vel[k];

    real ekin;
    MPI_Allreduce(&ekin_local, &ekin, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD );

    real epot;
    MPI_Allreduce(&epot_local, &epot, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD );
    epot *= 0.5;  // against double counting

    real etot = ekin + epot;             // total energy of the n-body system

    if (init_flag)                       // at first pass, pass the initial
        einit = etot;                    // energy back to the calling function

    tcpu = MPI_Wtime() - tcpu;
    if(rank==0) {


    cerr << "at time t = " << t << ", after " << nsteps
         << " steps (CPU = " << tcpu << "): \n  E_kin = " << ekin
         << " , E_pot = " << epot
         << " , E_tot = " << etot << endl;
    cerr << "                "
         << "absolute energy error: E_tot - E_init = "
         << etot - einit << endl;
    cerr << "                "
         << "relative energy error: (E_tot - E_init) / E_init = "
         << (etot - einit) / einit << endl;
    }
    if (x_flag){
        cerr << "  for debugging purposes, here is the internal data "
             << "representation:\n";
        for (int i = 0; i < n ; i++){
            cerr << "    internal data for particle " << i+1 << " : " << endl;
            cerr << "      ";
            cerr << p[i].id << " " << p[i].mass;
            for (int k = 0; k < NDIM; k++)
                cerr << ' ' << p[i].pos[k];
            for (int k = 0; k < NDIM; k++)
                cerr << ' ' << p[i].vel[k];
            for (int k = 0; k < NDIM; k++)
                cerr << ' ' << p[i].acc[k];
            for (int k = 0; k < NDIM; k++)
                cerr << ' ' << p[i].jerk[k];
            cerr << endl;
        }
    }
}
 
/*-----------------------------------------------------------------------------
 *  evolve  --  integrates an N-body system, for a total duration dt_tot.
 *              Snapshots are sent to the standard output stream once every
 *              time interval dt_out.  Diagnostics are sent to the standard
 *              error stream once every time interval dt_dia.
 *
 *  note: the integration time step, shared by all particles at any given time,
 *        is variable.  Before each integration step we use coll_time (short
 *        for collision time, an estimate of the time scale for any significant
 *        change in configuration to happen), multiplying it by dt_param (the
 *        accuracy parameter governing the size of dt in units of coll_time),
 *        to obtain the new time step size.
 *
 *  Before moving any particles, we start with an initial diagnostics output
 *  and snapshot output if desired.  In order to write the diagnostics, we
 *  first have to calculate the potential energy, with get_acc_jerk_pot_coll().
 *  That function also calculates accelerations, jerks, and an estimate for the
 *  collision time scale, all of which are needed before we can enter the main
 *  integration loop below.
 *       In the main loop, we take as many integration time steps as needed to
 *  reach the next output time, do the output required, and continue taking
 *  integration steps and invoking output this way until the final time is
 *  reached, which triggers a `break' to jump out of the infinite loop set up
 *  with `while(true)'.
 *-----------------------------------------------------------------------------
 */

void evolve(Particle p[], 
            int n, real & t, real dt_param, real dt_dia, real dt_out,
            real dt_tot, bool init_out, bool x_flag,
	    void *pipe, MPI_Datatype particletype)
{
    int rank, size;
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &size );

    if(rank==root) 
      cerr << "Starting a Hermite integration for a " << n*size
	   << "-body system,\n  from time t = " << t 
	   << " with time step control parameter dt_param = " << dt_param
	   << "  until time " << t + dt_tot 
	   << " ,\n  with diagnostics output interval dt_dia = "
	   << dt_dia << ",\n  and snapshot output interval dt_out = "
	   << dt_out << "." << endl;

    real tcpu = MPI_Wtime();           // check CPU usage

    real epot = 0;                     // potential energy of the n-body system
    real coll_time = VERY_LARGE_NUMBER;// collision (close encounter) time scale
    get_acc_jerk_pot_coll(p, n, epot, coll_time, pipe);

    int nsteps = 0;               // number of integration time steps completed
    real einit;                   // initial total energy of the system

    write_diagnostics(p, n, t, epot, nsteps, einit,
		      true, x_flag, tcpu);
    if (init_out)                                    // flag for initial output
      put_snapshot(p, n, t, particletype);

    real t_dia = t + dt_dia;           // next time for diagnostics output
    real t_out = t + dt_out;           // next time for snapshot output
    real t_end = t + dt_tot;           // final time, to finish the integration

    while (true){
        while (t < t_dia && t < t_out && t < t_end){
            real dt_local = dt_param * coll_time;
	    real dt;
	    MPI_Allreduce(&dt_local, &dt, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD); // synchronize time step
	    evolve_step(p, n, t, dt, epot, coll_time, pipe);
            nsteps++;
        }
        if (t >= t_dia){
            write_diagnostics(p, n, t, epot, nsteps,
                              einit, false, x_flag, tcpu);
            t_dia += dt_dia;
        }
        if (t >= t_out){
            put_snapshot(p, n, t, particletype);
            t_out += dt_out;
        }
        if (t >= t_end)
            break;
    }
}

/*-----------------------------------------------------------------------------
 *  evolve_step  --  takes one integration step for an N-body system, using the
 *                   Hermite algorithm.
 *-----------------------------------------------------------------------------
 */

void evolve_step(Particle p[], int n, real & t,
                 real dt, real & epot, real & coll_time,
		 void *pipe)
{

  Particle *po = new Particle[n];

    for (int i = 0; i < n ; i++)
        for (int k = 0; k < NDIM ; k++){
          po[i].pos[k] = p[i].pos[k];
          po[i].vel[k] = p[i].vel[k];
          po[i].acc[k] = p[i].acc[k];
          po[i].jerk[k] = p[i].jerk[k];
        }

    predict_step(p, n, dt);
    get_acc_jerk_pot_coll(p, n, epot, coll_time, pipe);
    correct_step(p, po, n, dt);
    t += dt;

    delete[] po;
}

/*-----------------------------------------------------------------------------
 *  predict_step  --  takes the first approximation of one Hermite integration
 *                    step, advancing the positions and velocities through a
 *                    Taylor series development up to the order of the jerks.
 *-----------------------------------------------------------------------------
 */

void predict_step(Particle p[], int n, real dt)
{
    for (int i = 0; i < n ; i++)
        for (int k = 0; k < NDIM ; k++){
            p[i].pos[k] += p[i].vel[k]*dt + p[i].acc[k]*dt*dt/2
                                      + p[i].jerk[k]*dt*dt*dt/6;
            p[i].vel[k] += p[i].acc[k]*dt + p[i].jerk[k]*dt*dt/2;
        }
}

/*-----------------------------------------------------------------------------
 *  correct_step  --  takes one iteration to improve the new values of position
 *                    and velocities, effectively by using a higher-order
 *                    Taylor series constructed from the terms up to jerk at
 *                    the beginning and the end of the time step.
 *-----------------------------------------------------------------------------
 */

void correct_step(Particle p[], Particle po[], int n, real dt)
{
    for (int i = 0; i < n ; i++)
        for (int k = 0; k < NDIM ; k++){
            p[i].vel[k] = po[i].vel[k] + (po[i].acc[k] + p[i].acc[k])*dt/2
                                       + (po[i].jerk[k] - p[i].jerk[k])*dt*dt/12;
            p[i].pos[k] = po[i].pos[k] + (po[i].vel[k] + p[i].vel[k])*dt/2
                                       + (po[i].acc[k] - p[i].acc[k])*dt*dt/12;
        }
}

/*-----------------------------------------------------------------------------
 *  get_acc_jerk_pot_coll  --  calculates accelerations and jerks, and as side
 *                             effects also calculates potential energy and
 *                             the time scale coll_time for significant changes
 *                             in local configurations to occur.
 *                                                  __                     __
 *                                                 |          -->  -->       |
 *               M                           M     |           r  . v        |
 *   -->          j    -->       -->          j    | -->        ji   ji -->  |
 *    a   ==  --------  r    ;    j   ==  -------- |  v   - 3 ---------  r   |
 *     ji     |-->  |3   ji        ji     |-->  |3 |   ji      |-->  |2   ji |
 *            | r   |                     | r   |  |           | r   |       |
 *            |  ji |                     |  ji |  |__         |  ji |     __|
 *                             
 *  note: it would be cleaner to calculate potential energy and collision time
 *        in a separate function.  However, the current function is by far the
 *        most time consuming part of the whole program, with a double loop
 *        over all particles that is executed every time step.  Splitting off
 *        some of the work to another function would significantly increase
 *        the total computer time (by an amount close to a factor two).
 *
 *  We determine the values of all four quantities of interest by walking
 *  through the system in a double {i,j} loop.  The first three, acceleration,
 *  jerk, and potential energy, are calculated by adding successive terms;
 *  the last, the estimate for the collision time, is found by determining the 
 *  minimum value over all particle pairs and over the two choices of collision
 *  time, position/velocity and sqrt(position/acceleration), where position and
 *  velocity indicate their relative values between the two particles, while
 *  acceleration indicates their pairwise acceleration.  At the start, the
 *  first three quantities are set to zero, to prepare for accumulation, while
 *  the last one is set to a very large number, to prepare for minimization.
 *       The integration loops only over half of the pairs, with j > i, since
 *  the contributions to the acceleration and jerk of particle j on particle i
 *  is the same as those of particle i on particle j, apart from a minus sign
 *  and a different mass factor.
 *-----------------------------------------------------------------------------
 */

void get_acc_jerk_pot_coll(Particle pl[], int nl, 
			   Particle po[], int no, 
			   real & epot, real & coll_time)
{

    real coll_time_q = VERY_LARGE_NUMBER;      // collision time to 4th power
    real coll_est_q;                           // collision time scale estimate
                                               // to 4th power (quartic)
    for (int i = 0; i < nl ; i++){
        for (int j = 0; j < no ; j++){            // rji[] is the vector from
	  if(pl[i].id!=po[j].id) {
            real rji[NDIM];                        // particle i to particle j
            real vji[NDIM];                        // vji[] = d rji[] / d t
            for (int k = 0; k < NDIM ; k++){
                rji[k] = po[j].pos[k] - pl[i].pos[k];
                vji[k] = po[j].vel[k] - pl[i].vel[k];
            }
            real r2 = 0;                           // | rji |^2
            real v2 = 0;                           // | vji |^2
            real rv_r2 = 0;                        // ( rij . vij ) / | rji |^2
            for (int k = 0; k < NDIM ; k++){
                r2 += rji[k] * rji[k];
                v2 += vji[k] * vji[k];
                rv_r2 += rji[k] * vji[k];
            }
            rv_r2 /= r2;
            real r = sqrt(r2);                     // | rji |
            real r3 = r * r2;                      // | rji |^3

// add the {i,j} contribution to the total potential energy for the system:

            epot -= pl[i].mass * po[j].mass / r;

// add the {j (i)} contribution to the {i (j)} values of acceleration and jerk:

            real da[3];                            // main terms in pairwise
            real dj[3];                            // acceleration and jerk
            for (int k = 0; k < NDIM ; k++){
                da[k] = rji[k] / r3;                           // see equations
                dj[k] = (vji[k] - 3 * rv_r2 * rji[k]) / r3;    // in the header
            }
            for (int k = 0; k < NDIM ; k++){
                pl[i].acc[k] += po[j].mass * da[k];           // using symmetry
		pl[i].jerk[k] += po[j].mass * dj[k];          // acceleration

		// in the original version pij = -pji for acc and jerk.
		// in this parallel version this is unpractical.
                //po[j].acc[k] -= pl[i].mass * da[k];      // find pairwise
		//po[j].jerk[k] -= pl[i].mass * dj[k];     // and jerk
            }

// first collision time estimate, based on unaccelerated linear motion:

            coll_est_q = (r2*r2) / (v2*v2);
            if (coll_time_q > coll_est_q)
                coll_time_q = coll_est_q;

// second collision time estimate, based on free fall:

            real da2 = 0;                                  // da2 becomes the 
            for (int k = 0; k < NDIM ; k++)                // square of the 
                da2 += da[k] * da[k];                      // pair-wise accel-
            double mij = pl[i].mass + po[j].mass;            // eration between
            da2 *= mij * mij;                              // particles i and j

            coll_est_q = r2/da2;
            if (coll_time_q > coll_est_q)
                coll_time_q = coll_est_q;
	  }
        }                                     
    }    
    // from q for quartic back to linear collision time and taking the minimum
    coll_time = min(coll_time, sqrt(sqrt(coll_time_q))); 
}                                             

/*-----------------------------------------------------------------------------
 *  get_acc_jerk_pot_coll  --  the distribution of particles over 
 *                             neighboring processors and subsequent force
 *                             calculation.
 *-----------------------------------------------------------------------------
 */

void get_acc_jerk_pot_coll(Particle p[], int n, real &epot, real &coll_time, 
			   void *pipe) {

  int rank, size;
  MPI_Comm_rank( MPI_COMM_WORLD, &rank );
  MPI_Comm_size( MPI_COMM_WORLD, &size );

    int rlen;
    Particle *recvbuf;

    for (int i = 0; i < n ; i++)
      for (int k = 0; k < NDIM ; k++) {
	p[i].acc[k] = p[i].jerk[k] = 0;
      }

    MPE_Pipe_start( pipe, p, n, 1 ); // load the initial sendbuffer 

    epot = 0;                        // initialize epot and coll_time
    coll_time = VERY_LARGE_NUMBER;
    get_acc_jerk_pot_coll(p, n, p, n, epot, coll_time);

    for (int step=1; step<size; step++) { // compute forces for other particles

      MPE_Pipe_push( pipe, (void**)&recvbuf, &rlen );        // get new data
      
      // Compute forces 
      get_acc_jerk_pot_coll(p, n, recvbuf, rlen, epot, coll_time); 
    }
}

/*-----------------------------------------------------------------------------
 *                                                                    \\   o
 *  end of file:  nbody_sh1.C                                         /\\'  O
 *                                                                   /\     |
 *=============================================================================
 */
